<?php
	class model{

	var $host = "localhost";
	var $uname = "root";
	var $pass = "";
	var $db = "jurnal_10desi"; //isi sesuai nama database anda

	function __construct(){
		$this->conn = mysqli_connect($this->host, $this->uname,$this->pass,$this->db);
		//inisialisasi awal untuk class biasa disebut instansiasi
		// function __construct(){
		// 	$this->conn = mysql_connect("localhost", "root", " ","jurnal_10desi");
			//buatlah koneksi seperti modul 9 kemarin
			
		}
		
		function execute($query){
			return $this->conn->query($query);
		}
		
		function selectAll(){
			$query = "SELECT * FROM mahasiswa";
			//query select*from 
			return $this->execute($query);
		}
		
		function selectMhs($nim){
			$query = "SELECT * FROM mahasiswa WHERE nim='$nim'";
			//query select mahasiswa berdasarkan nim
			return $this->execute($query);
		}
		
		function updateMhs($nim, $nama, $angkatan, $fakultas, $prodi){
			$query = "UPDATE mahasiswa SET nim='$nim', nama='$nama', angkatan='$angkatan', fakultas='$fakultas', program='$prodi' WHERE nim='$nim'";
			//query update nim, nama, angkatan, fakultas, prodi
			return $this->execute($query);
		}
		
		function deleteMhs($nim){
			$query = "DELETE FROM mahasiswa WHERE nim='$nim'";
			//query delete berdasarkan nim
			return $this->execute($query);
		}
		
		function insertMhs($nim, $nama, $angkatan, $fakultas, $prodi){
			$query = "INSERT INTO mahasiswa VALUES ('$nim', '$nama', '$angkatan', '$fakultas', '$prodi')";
			//query insert nim,nama, angkatan, fakultas, prodi
			return $this->execute($query);
		}
		
		function fetch($var){
			return mysqli_fetch_array($var);
		}
		
		//pasangan construct adalah destruct untuk menghapus inisialisasi class pada memori
		function __destruct(){
		}
	}
?>